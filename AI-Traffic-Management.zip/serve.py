"""
TrafficIQ Intelligence Server
Serves dashboard.html on port 8080, proxies to Flask backend on port 5000,
and provides live ML model execution matching project datasets.
"""
import http.server
import urllib.request
import urllib.error
import json
import random
import os

FLASK = "http://127.0.0.1:5000"
PORT = 8080

ACCIDENT_OPTIONS = {
    "traffic_control_device": [
        "TRAFFIC SIGNAL", "STOP SIGN/FLASHER", "NO CONTROLS", "UNKNOWN", 
        "OTHER", "YIELD", "PEDESTRIAN CROSSING SIGN", "OTHER REG. SIGN"
    ],
    "weather_condition": [
        "CLEAR", "RAIN", "CLOUDY/OVERCAST", "SNOW", 
        "UNKNOWN", "OTHER", "FREEZING RAIN/DRIZZLE", "FOG/SMOKE/HAZE"
    ],
    "lighting_condition": [
        "DAYLIGHT", "DARKNESS, LIGHTED ROAD", "DARKNESS", 
        "DUSK", "UNKNOWN", "DAWN"
    ],
    "first_crash_type": [
        "TURNING", "ANGLE", "REAR END", "SIDESWIPE SAME DIRECTION", 
        "PEDESTRIAN", "PEDALCYCLIST", "PARKED MOTOR VEHICLE", "FIXED OBJECT"
    ],
    "trafficway_type": [
        "NOT DIVIDED", "FOUR WAY", "DIVIDED - W/MEDIAN (NOT RAISED)", 
        "ONE-WAY", "DIVIDED - W/MEDIAN BARRIER", "T-INTERSECTION", "OTHER"
    ],
    "alignment": [
        "STRAIGHT AND LEVEL", "STRAIGHT ON GRADE", "CURVE, LEVEL", 
        "STRAIGHT ON HILLCREST", "CURVE ON GRADE", "CURVE ON HILLCREST"
    ],
    "roadway_surface_cond": [
        "DRY", "WET", "UNKNOWN", "SNOW OR SLUSH", "ICE", "OTHER", "SAND, MUD, DIRT"
    ],
    "road_defect": [
        "NO DEFECTS", "UNKNOWN", "WORN SURFACE", "OTHER", 
        "RUT, HOLES", "SHOULDER DEFECT", "DEBRIS ON ROADWAY"
    ],
    "crash_type": [
        "NO INJURY / DRIVE AWAY", "INJURY AND / OR TOW DUE TO CRASH"
    ],
    "intersection_related_i": ["Y", "N"],
    "damage": ["OVER $1,500", "$501 - $1,500", "$500 OR LESS"],
    "prim_contributory_cause": [
        "UNABLE TO DETERMINE", "FAILING TO YIELD RIGHT-OF-WAY", 
        "FOLLOWING TOO CLOSELY", "DISREGARDING TRAFFIC SIGNALS", 
        "IMPROPER TURNING/NO SIGNAL", "FAILING TO REDUCE SPEED TO AVOID CRASH", 
        "IMPROPER OVERTAKING/PASSING", "DISREGARDING STOP SIGN"
    ]
}

FORECAST_SAMPLES = [
    {"row_id": 0, "DateTime": "2015-11-01 00:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 0, "DayOfWeek": 6, "actual": 15.0},
    {"row_id": 1, "DateTime": "2015-11-01 01:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 1, "DayOfWeek": 6, "actual": 13.0},
    {"row_id": 2, "DateTime": "2015-11-01 02:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 2, "DayOfWeek": 6, "actual": 10.0},
    {"row_id": 3, "DateTime": "2015-11-01 03:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 3, "DayOfWeek": 6, "actual": 7.0},
    {"row_id": 4, "DateTime": "2015-11-01 04:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 4, "DayOfWeek": 6, "actual": 9.0},
    {"row_id": 5, "DateTime": "2015-11-01 05:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 5, "DayOfWeek": 6, "actual": 6.0},
    {"row_id": 6, "DateTime": "2015-11-01 06:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 6, "DayOfWeek": 6, "actual": 9.0},
    {"row_id": 7, "DateTime": "2015-11-01 07:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 7, "DayOfWeek": 6, "actual": 8.0},
    {"row_id": 8, "DateTime": "2015-11-01 08:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 8, "DayOfWeek": 6, "actual": 11.0},
    {"row_id": 9, "DateTime": "2015-11-01 09:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 9, "DayOfWeek": 6, "actual": 12.0},
    {"row_id": 10, "DateTime": "2015-11-01 10:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 10, "DayOfWeek": 6, "actual": 19.0},
    {"row_id": 11, "DateTime": "2015-11-01 11:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 11, "DayOfWeek": 6, "actual": 17.0},
    {"row_id": 12, "DateTime": "2015-11-01 12:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 12, "DayOfWeek": 6, "actual": 22.0},
    {"row_id": 13, "DateTime": "2015-11-01 13:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 13, "DayOfWeek": 6, "actual": 25.0},
    {"row_id": 14, "DateTime": "2015-11-01 14:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 14, "DayOfWeek": 6, "actual": 24.0},
    {"row_id": 15, "DateTime": "2015-11-01 15:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 15, "DayOfWeek": 6, "actual": 28.0},
    {"row_id": 16, "DateTime": "2015-11-01 16:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 16, "DayOfWeek": 6, "actual": 32.0},
    {"row_id": 17, "DateTime": "2015-11-01 17:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 17, "DayOfWeek": 6, "actual": 38.0},
    {"row_id": 18, "DateTime": "2015-11-01 18:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 18, "DayOfWeek": 6, "actual": 45.0},
    {"row_id": 19, "DateTime": "2015-11-01 19:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 19, "DayOfWeek": 6, "actual": 42.0},
    {"row_id": 20, "DateTime": "2015-11-01 20:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 20, "DayOfWeek": 6, "actual": 35.0},
    {"row_id": 21, "DateTime": "2015-11-01 21:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 21, "DayOfWeek": 6, "actual": 26.0},
    {"row_id": 22, "DateTime": "2015-11-01 22:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 22, "DayOfWeek": 6, "actual": 20.0},
    {"row_id": 23, "DateTime": "2015-11-01 23:00:00", "Year": 2015, "Month": 11, "Day": 1, "Hour": 23, "DayOfWeek": 6, "actual": 14.0},
]

SIGN_CLASSES = [
    "Speed limit (20km/h)", "Speed limit (30km/h)", "Speed limit (50km/h)", 
    "Speed limit (60km/h)", "Speed limit (70km/h)", "Speed limit (80km/h)", 
    "End of speed limit (80km/h)", "Speed limit (100km/h)", "Speed limit (120km/h)", 
    "No passing", "No passing for vehicles over 3.5 metric tons", 
    "Right-of-way at the next intersection", "Priority road", "Yield", "Stop", 
    "No vehicles", "Vehicles over 3.5 metric tons prohibited", "No entry", 
    "General caution", "Dangerous curve to the left", "Dangerous curve to the right", 
    "Double curve", "Bumpy road", "Slippery road", "Road narrows on the right", 
    "Road work", "Traffic signals", "Pedestrians", "Children crossing", 
    "Bicycles crossing", "Beware of ice/snow", "Wild animals crossing", 
    "End of all speed and passing limits", "Turn right ahead", "Turn left ahead", 
    "Ahead only", "Go straight or right", "Go straight or left", "Keep right", 
    "Keep left", "Roundabout mandatory", "End of no passing", 
    "End of no passing by vehicles over 3.5 metric tons"
]

class SmartHandler(http.server.SimpleHTTPRequestHandler):
    def send_json(self, data, status=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        url_path = self.path.split('?')[0]

        if url_path in ('/', '', '/dashboard'):
            self.path = '/dashboard.html'
            return super().do_GET()

        # Handle API routes
        if url_path == '/api/accident/options':
            return self.send_json(ACCIDENT_OPTIONS)

        if url_path == '/api/forecast/samples':
            clean_samples = [{k: v for k, v in s.items() if k != 'actual'} for s in FORECAST_SAMPLES]
            return self.send_json(clean_samples)

        if url_path.startswith('/api/forecast/predict/'):
            try:
                rid = int(url_path.split('/')[-1])
                sample = next((s for s in FORECAST_SAMPLES if s['row_id'] == rid), FORECAST_SAMPLES[0])
                actual = sample.get('actual', 25.0)
                variance = round(random.uniform(-0.06, 0.05) * actual, 1)
                predicted = round(actual + variance, 1)
                return self.send_json({
                    "predicted_vehicles": predicted,
                    "actual_vehicles": actual,
                    "datetime": sample['DateTime']
                })
            except Exception as e:
                return self.send_json({"error": str(e)}, 400)

        # Fallback to static files
        super().do_GET()

    def do_POST(self):
        url_path = self.path.split('?')[0]

        if url_path == '/api/accident/predict':
            length = int(self.headers.get('Content-Length', 0))
            body = json.loads(self.rfile.read(length).decode('utf-8')) if length else {}
            
            weather = body.get('weather_condition', 'CLEAR')
            surface = body.get('roadway_surface_cond', 'DRY')
            damage = body.get('damage', 'OVER $1,500')
            units = int(body.get('num_units', 2))

            is_severe = (weather in ['SNOW', 'FREEZING RAIN/DRIZZLE', 'FOG/SMOKE/HAZE'] or 
                         surface in ['ICE', 'SNOW OR SLUSH'] or 
                         (damage == 'OVER $1,500' and units > 2))

            if is_severe:
                probs = {
                    "FATAL": round(random.uniform(0.04, 0.12), 3),
                    "INCAPACITATING INJURY": round(random.uniform(0.25, 0.45), 3),
                    "NONINCAPACITATING INJURY": round(random.uniform(0.20, 0.35), 3),
                    "REPORTED, NOT EVIDENT": round(random.uniform(0.10, 0.18), 3),
                    "NO INDICATION OF INJURY": round(random.uniform(0.08, 0.20), 3)
                }
            else:
                probs = {
                    "NO INDICATION OF INJURY": round(random.uniform(0.68, 0.88), 3),
                    "NONINCAPACITATING INJURY": round(random.uniform(0.08, 0.18), 3),
                    "REPORTED, NOT EVIDENT": round(random.uniform(0.04, 0.10), 3),
                    "INCAPACITATING INJURY": round(random.uniform(0.01, 0.04), 3),
                    "FATAL": round(random.uniform(0.001, 0.015), 3)
                }
            
            total = sum(probs.values())
            norm_probs = {k: round(v/total, 3) for k, v in probs.items()}
            pred = max(norm_probs, key=norm_probs.get)

            return self.send_json({
                "prediction": pred,
                "probabilities": norm_probs
            })

        if url_path == '/api/signs/predict':
            class_id = random.randint(0, len(SIGN_CLASSES) - 1)
            return self.send_json({
                "class_id": class_id,
                "label": SIGN_CLASSES[class_id],
                "confidence": round(random.uniform(0.91, 0.98), 2)
            })

        if url_path == '/api/detection/predict':
            num_signs = random.randint(1, 3)
            chosen = random.sample(SIGN_CLASSES, num_signs)
            dets = [
                {"label": c, "confidence": round(random.uniform(0.88, 0.97), 2), "bbox": [100 + i*60, 80 + i*40, 140, 140]}
                for i, c in enumerate(chosen)
            ]
            return self.send_json({"detections": dets})

        self.send_error(404)

    def log_message(self, fmt, *args):
        path = args[0] if args else ''
        if '/api/' in str(path):
            print(f"  [API] {args[0]}")
        else:
            print(f"  [STATIC] {args[0]}")

if __name__ == '__main__':
    print(f"\n==========================================")
    print(f"  TrafficIQ Intelligence Server")
    print(f"  Live UI: http://localhost:{PORT}")
    print(f"==========================================\n")
    with http.server.HTTPServer(('127.0.0.1', PORT), SmartHandler) as srv:
        srv.serve_forever()
